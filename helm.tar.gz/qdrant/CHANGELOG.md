# Changelog

## [qdrant-1.15.1](https://github.com/qdrant/qdrant-helm/tree/qdrant-1.15.1) (2025-07-24)

- Update Qdrant to v1.15.1
- Add support for additional annotations in Kubernetes resource templates [#359](https://github.com/qdrant/qdrant-helm/pull/359)

